# Site acessível sobre Aluguel de casas
# Sobre
Refatoração de um site implementando recursos de acessibilidade no html, css e JS.
## Recursos de acessibilidade
- Atributos aria
- alt
- tab-index
- menu de acessibilidade
## Tecnologias utilizadas
- Bootstrap
- ScrollRevealjs
- HTML
- CSS
- JS
